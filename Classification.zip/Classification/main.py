import os
import numpy as np
from TRKM import TRKM
import warnings
warnings.filterwarnings("ignore")

directory = './Dat'
file_list = os.listdir(directory)

for file_name in file_list:
    if file_name.endswith(".csv"):
        file_path = os.path.join(directory, file_name)
        print(directory)
        print(file_name)
        file_data = np.loadtxt(file_path, delimiter=',')
        
        m, n = file_data.shape
        for i in range(m):
            if file_data[i, n-1] == 0:
                file_data[i, n-1] = -1
    
        np.random.seed(0)
        indices = np.random.permutation(m)
        file_data = file_data[indices]
        A_train=file_data[0:int(m*(1-0.30))]
        A_test=file_data[int(m * (1-0.30)):]

        c_1_best = 0.1
        c2_best = 0.001
        mew1_best = 4
    
        Eval, Test_time = TRKM(A_train, A_test, c_1_best,c_1_best, c2_best,c2_best, mew1_best)
        Test_accuracy=Eval[0]
        print('Test_accuracy:', Test_accuracy)