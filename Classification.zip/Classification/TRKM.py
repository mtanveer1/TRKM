import numpy as np
import time
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score

def calculate_kA(A, C, mew):
    norm_A = np.linalg.norm(A, axis=1)[:, np.newaxis]
    norm_C = np.linalg.norm(C, axis=1)

    first_term = np.power(norm_A, 2)
    second_term = -2 * np.dot(A, C.T)
    third_term = np.power(norm_C, 2)

    kA = np.exp(-(1 / (2 * mew)) * (first_term + second_term + third_term))
    return kA


def TRKM(train_data, test_data, eta1,eta2,lambd1,lambd2, mew):
    # np.random.seed(2)
    

    start = time.time()

    A = train_data[train_data[:, -1] == 1, :-1]
    B = train_data[train_data[:, -1] != 1, :-1]
 
    p = A.shape[0]
    q = B.shape[0]

    k_A_B = calculate_kA(A, B, mew)
    eta_inv1 = 1/eta1
    e1=np.ones((p,1))
    e2=np.ones((q, 1))

    Rh11 = e1 + eta_inv1* np.dot(k_A_B, e2)
    one_array = q*np.ones((Rh11.shape[1], 1))
    Rh1 = np.vstack((Rh11, one_array))

    Rh21 = np.hstack((eta_inv1*calculate_kA(A, A, mew) + lambd1*np.ones(p), e1))
    e1_transposed = e1.T
    zero_array = np.zeros((e1_transposed.shape[0], 1))
    Rh22 = np.hstack((e1_transposed, zero_array))
    Rh2 = np.vstack((Rh21, Rh22))
    Rh2 = Rh2 + 0.05* np.eye(Rh2.shape[1])
    H1_b1 = np.dot(np.linalg.inv(Rh2), Rh1)
    h1 = H1_b1[:-1]
    b1 = H1_b1[-1]

    k_B_A = calculate_kA(B, A, mew)
    eta_inv2 = 1/eta2
    

    Rt11 = e2 + eta_inv2* np.dot(k_B_A, e1)
    one_array1 = p*np.ones((Rt11.shape[1], 1))

    Rt1 = -np.vstack((Rt11, one_array1))

    Rt21 = np.hstack((eta_inv2*calculate_kA(B, B, mew) + lambd2*np.ones(q), e2))
    e2_transposed = e2.T
    zero_array1 = np.zeros((e2_transposed.shape[0], 1))
    Rt22 = np.hstack((e2_transposed, zero_array1))
    Rt2 = np.vstack((Rt21, Rt22))
    Rt2 = Rt2 + 0.05* np.eye(Rt2.shape[1])
    H2_b2 = np.dot(np.linalg.inv(Rt2), Rt1)
    h2 = H2_b2[:-1]
    b2 = H2_b2[-1]

    TestX = test_data[:, :-1]

    K_X_A = calculate_kA(TestX, A, mew)
    K_X_B = calculate_kA(TestX, B, mew)


    y1 = eta_inv1*np.dot(K_X_A, h1) - eta_inv1*np.dot(K_X_B, e2)  + b1
    y2 = eta_inv2*np.dot(K_X_B, h2) + eta_inv2*np.dot(K_X_A, e1) + b2

    

    y_pred = np.zeros((y1.shape[0], 1))
    for i in range(y1.shape[0]):
        if np.min([np.abs(y1[i]), np.abs(y2[i])]) == np.abs(y1[i]):
            y_pred[i] = 1
        else:
            y_pred[i] = -1

    # y_pred = np.sign(np.abs(y2) - np.abs(y1))
    
    obs1 = test_data[:, [-1]]

    # Calculate confusion matrix
    tn, fp, fn, tp = confusion_matrix(obs1, y_pred).ravel()

    # Calculate accuracy
    accuracy = accuracy_score(obs1, y_pred)
    accuracy = accuracy*100

    # Calculate precision
    precision = precision_score(obs1, y_pred)

    # Calculate recall (sensitivity)
    recall = recall_score(obs1, y_pred)

    # Calculate specificity
    specificity = tn / (tn + fp)
    sensitivity = tp / (tp + fn)


    # Calculate F1 score
    f1 = f1_score(obs1, y_pred)

    # Calculate G-mean
    gmean = np.sqrt(recall * specificity)

    EVAL_Validation = [accuracy, sensitivity, specificity, precision, recall, f1, gmean, tp, tn, fp, fn]
    end = time.time()
    Time=end - start
    return EVAL_Validation,Time
