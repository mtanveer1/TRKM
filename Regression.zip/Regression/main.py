import os
import numpy as np
from TRKM import TRKM

directory = './Dat'
file_list = os.listdir(directory)

for file_name in file_list:
    if file_name.endswith(".csv"):
        file_path = os.path.join(directory, file_name)
        print(directory)
        print(file_name)
        file_data = np.loadtxt(file_path, delimiter=',')

        file_data=file_data.T
        st=np.std(file_data, axis=0, ddof=1)
        mu=np.mean(file_data, axis=0)
        z=(file_data-mu)/st
        file_data=z.T

        m, n = file_data.shape
        A_train=file_data[0:int(m*(1-0.30))]
        A_test=file_data[int(m * (1-0.30)):] 
    
        C1_best = 0.01
        c2_best = 0.00001
        mew_best = 8

        RMSE,MAE,SMAPE, MAPE,SSE, SST,SSE_SST, pos_error, neg_error, Test_time = TRKM(A_train, A_test, C1_best,C1_best, c2_best,c2_best, mew_best)
        
        print("RMSE: ", RMSE)
        print("MAE: ", MAE)
        print("Positive Error: ", pos_error)
        print("Negative Error: ", neg_error)


