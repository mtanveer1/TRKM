import numpy as np
import time
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score

def calculate_kA(A, C, mew):
    norm_A = np.linalg.norm(A, axis=1)[:, np.newaxis]
    norm_C = np.linalg.norm(C, axis=1)

    first_term = np.power(norm_A, 2)
    second_term = -2 * np.dot(A, C.T)
    third_term = np.power(norm_C, 2)

    kA = np.exp(-(1 / (2 * mew)) * (first_term + second_term + third_term))
    return kA


def TRKM(train_data, test_data, eta1,eta2,lambd1,lambd2, mew): 

    start = time.time()
    A = train_data[:,:-1]
    Y = train_data[:,[-1]]
    p = A.shape[0]

    k_A_A = calculate_kA(A, A, mew)
    eta_inv1 = 1/eta1
    e=np.ones((p,1))

    Rh11 = -Y + eta_inv1* np.dot(k_A_A, e)
    one_array = p*np.ones((Rh11.shape[1], 1))

    Rh1 = np.vstack((Rh11, one_array))

    Rh21 = np.hstack((eta_inv1*k_A_A + lambd1*np.ones(p), -e))
    e_transposed = e.T
    zero_array = np.zeros((e_transposed.shape[0], 1))
    Rh22 = np.hstack((e_transposed, zero_array))
    Rh2 = np.vstack((Rh21, Rh22))
    Rh2 = Rh2 + 0.05* np.eye(Rh2.shape[1])
    H1_b1 = np.dot(np.linalg.inv(Rh2), Rh1)
    h1 = H1_b1[:-1]
    b1 = H1_b1[-1]

    eta_inv2 = 1/eta2
    Rt11 = Y + eta_inv2* np.dot(k_A_A, e)
    # one_array1 = -np.ones((Rt11.shape[1], 1))
    Rt1 = np.vstack((Rt11, one_array))

    Rt21 = np.hstack((eta_inv2*k_A_A + lambd2*np.ones(p), e))
    zero_array1 = np.zeros((e_transposed.shape[0], 1))
    Rt22 = np.hstack((e_transposed, zero_array1))
    Rt2 = np.vstack((Rt21, Rt22))
    Rt2 = Rt2 + 0.05* np.eye(Rt2.shape[1])
    H2_b2 = np.dot(np.linalg.inv(Rt2), Rt1)
    h2 = H2_b2[:-1]
    b2 = H2_b2[-1]

    TestX = test_data[:, :-1]
    Y_test = test_data[:,[-1]]
    Ker_test = calculate_kA(TestX, A, mew)

    # y1 = np.dot(Ker_test, h1)  + b1
    # y2 = np.dot(Ker_test, h2)  + b2

    y1 = eta_inv1*np.dot(Ker_test, (e-h1)) + b1 
    y2 = eta_inv1*np.dot(Ker_test, (h2-e)) + b2 

    predictedY = (y1 + y2) * 0.5

    # Calculate RMSE
    RMSE = np.sqrt(np.mean((Y_test - predictedY) ** 2))

    # Calculate MAE
    MAE = np.mean(np.abs(Y_test - predictedY))

    # Calculate SMAPE
    SMAPE = np.mean(2 * np.abs(Y_test - predictedY) / (np.abs(Y_test) + np.abs(predictedY))) * 100

    # Calculate MAPE
    MAPE = np.mean(np.abs((Y_test - predictedY) / Y_test)) * 100

    # Calculate SSE
    SSE = np.sum((Y_test - predictedY) ** 2)

    # Calculate SST
    meanTestY = np.mean(Y)
    SST = np.sum((Y_test - meanTestY) ** 2)

    # Calculate SSE/SST
    SSE_SST = SSE / SST

    # Finding positive and negative errors
    # Initialize lists to store positive and negative errors
    positive_error = []
    negative_error = []

    # Calculate errors
    errors = Y_test - predictedY

    # Iterate through the errors and classify them
    for error in errors:
        if error > 0:
            positive_error.append(error)
        elif error < 0:
            negative_error.append(error)

    # Calculate average positive and negative errors
    pos_error = np.sum(np.abs(positive_error)) / len(positive_error) if positive_error else 0
    neg_error = np.sum(np.abs(negative_error)) / len(negative_error) if negative_error else 0
    

    end = time.time()
    Time=end - start
    return RMSE,MAE,SMAPE, MAPE,SSE, SST,SSE_SST, pos_error, neg_error,Time

